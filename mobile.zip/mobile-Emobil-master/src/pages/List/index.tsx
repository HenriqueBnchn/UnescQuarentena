import React from 'react';
import { View, AsyncStorage } from 'react-native';
import { useEffect, useState } from 'react';

const List = () => {
    // const [projects, setProjects] = useState([]);
 
    // useEffect(() => {
    //     AsyncStorage.getItem('projects').then(storagedProj => {
    //         const projArray = storagedProj.split(',').map(project => project.trim());

    //         setProjects(projArray);
    //     })
    //  },[]);
 return <View/>
}

export default List;