import React from 'react';
import { View } from 'react-native';

const Detail = () => {
    return <View/>
}

export default Detail;