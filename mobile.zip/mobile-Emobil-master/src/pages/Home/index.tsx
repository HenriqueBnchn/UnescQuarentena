import React, {useState, useEffect} from 'react';
import {Feather as Icon} from '@expo/vector-icons';
import {View,Image, StyleSheet, Text, ImageBackground, TextInput, KeyboardAvoidingView, Platform, AsyncStorage} from 'react-native';
import {RectButton} from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';

import styles from './styles' 

const Home = () => {

    const [email, setEmail] =useState('');
    const [password,setPassword] =useState('');
    const navigation = useNavigation();

    useEffect(()=>{
      AsyncStorage.getItem('user').then(user =>{
        if(user){
          navigation.navigate('List')
        }
      })
    })

    function handleNavigationToList(){
     navigation.navigate('List', {
            email,
            password
        }) 

        

       
    }
    function handleNavigationToForm(){
      navigation.navigate('CadUser')
    }


    return (
     <KeyboardAvoidingView 
     style={{flex:1}}
     behavior = {Platform.OS === 'ios' ? 'padding' : undefined}
     
    >   
        <View 
            //source={require('../../assets/home-background.png')} 
            style={ styles.container}
            //imageStyle ={{width:274, height:170}}
            >
            <View style={styles.main}>
            <Image source={require('../../assets/logo.png')} />
            <View>
            <Text style={styles.title}>Encontre seu Imóvel perfeito. </Text>
            <Text style={styles.description}>Ajudamos voçê a realizar seu sonho.</Text>
            </View>
            </View>

            <View style={styles.footer}>
                <TextInput 
                    style={styles.input}
                    placeholder="Digite seu email"
                    value = {email}
                    maxLength = {20}
                    keyboardType ="email-address"
                    returnKeyType ="next"
                    autoFocus
                    autoCapitalize ="none"
                    autoCorrect={false}
                    onChangeText={text => setEmail(text)}

                />
                <TextInput 
                    style={styles.input}
                    placeholder="Digite sua senha"
                    secureTextEntry
                    value = {password}
                    autoCorrect = {false}
                    onChangeText={text => setPassword(text)}
                    returnKeyType = "send"

                />

                <RectButton style ={styles.button} onPress={handleNavigationToList}>
                    <View style={styles.buttonIcon}>
                        <Text>
                            <Icon name="arrow-right" color= "#FFF" size={24} />
                        </Text>
                    </View>
                    <Text style={styles.buttonText}>
                        Entrar

                </Text>
                
                </RectButton>


                <RectButton style ={styles.button2} onPress={handleNavigationToForm}>
                    <View style={styles.buttonIcon}>
                        <Text>
                            <Icon name="arrow-right" color= "#FFF" size={24} />
                        </Text>
                    </View>
                    <Text style={styles.buttonText}>
                        Cadastre-se

                </Text>
                
                </RectButton>




            </View>

        </View>
    </KeyboardAvoidingView>
    );
};

export default Home; 
