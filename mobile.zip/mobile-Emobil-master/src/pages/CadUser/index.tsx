import React  from 'react';
import {View,Image, StyleSheet, Text,  TextInput, KeyboardAvoidingView, Platform, AsyncStorage, Alert} from 'react-native';
import {RectButton} from 'react-native-gesture-handler';
import {Feather as Icon} from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useEffect, useState } from 'react';
import api from '../../services/api';












const CadUser = () => {
    
    
 



    const [city, setCity]= useState('');
    const [state, setState]= useState('');
    const [number, setNumber]= useState('');
    const [street, setStreet]= useState('');
    const [email, setEmail] =useState('');
    const [password,setPassword] =useState('');
    const [password_confirmation,setConfirmed] =useState('');
    const [username, setUsername] = useState('');
    const navigation = useNavigation();
    
    const [formData, setData] =useState({
        username: '',
        email: '',
        password: '',
        password_confirmation:'',
        street: '',
        number: '',
        state: '',
        city: '',

    });




  async  function handleNavigationToList(){
       
        await api.post('/users');

        Alert.alert('Cadastro foi realizado com sucesso, pode voltar e fazer o login')

        navigation.goBack();
        

       
    }
  


  
    return (

            


        <KeyboardAvoidingView 
        style={{flex:1}}
        behavior = {Platform.OS === 'ios' ? 'padding' : undefined}
        
       >   
           <View
               //source={require('../../assets/home-background.png')} 
               style={ styles.container}
               //imageStyle ={{width:274, height:350}}
               >
               <View style={styles.main}>
               <Image source={require('../../assets/logo.png')} />
               </View>
   
               <View style={styles.footer}>
                   
               <TextInput 
                       style={styles.input}
                       placeholder="Digite seu username"
                       value = {formData.username}
                       autoCorrect = {false}
                       onChangeText={text => setData(text)}
   
                   />
                   
                   <TextInput 
                       style={styles.input}
                       placeholder="Digite seu email"
                       value = {email}
                       maxLength = {20}
                       autoCapitalize ="none"
                       autoCorrect={false}
                       onChangeText={text => setEmail(text)}
   
                   />
                   <TextInput 
                       style={styles.input}
                       placeholder="Digite sua senha"
                       value = {password}
                       autoCorrect = {false}
                       onChangeText={text => setPassword(text)}
   
                   />
                   <TextInput 
                       style={styles.input}
                       placeholder="Confirme sua senha"
                       value = {password_confirmation}
                       autoCorrect = {false}
                       onChangeText={text => setConfirmed(text)}
   
                   />

                    <Text style={styles.title}>Endereço </Text>
                    <Text/>
                    
                    
                    <TextInput
                       style={styles.input}
                       placeholder="Digite sua rua"
                       value = {street}
                       autoCorrect = {false}
                       onChangeText={text =>setStreet(text)}
                        />

                    <TextInput
                       style={styles.input2}
                       placeholder= "Nº"
                       value = {number}
                       autoCorrect = {false}
                       onChangeText={text =>setNumber(text)}
                        />

                    <TextInput
                       style={styles.input3}
                       placeholder="Estado"
                       value = {state}
                       autoCorrect = {false}
                       onChangeText={text =>setState(text)}
                        />

                    <TextInput
                       style={styles.input}
                       placeholder="Cidade"
                       value = {city}
                       autoCorrect = {false}
                       onChangeText={text =>setCity(text)}
                        />
                        
                       
                    
                   <RectButton style ={styles.button} onPress={handleNavigationToList}>
                       <View style={styles.buttonIcon}>
                           <Text>
                               <Icon name="arrow-right" color= "#FFF" size={24} />
                           </Text>
                       </View>
                       <Text style={styles.buttonText}>
                           Create
   
                   </Text>
                   
                   </RectButton>
   
   
   
   
   
               </View>
   
           </View>
       </KeyboardAvoidingView>
       );




};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 22,
      justifyContent: 'center'
     
    },
  
    main: {
      flex: 1,
      justifyContent: 'center',
      marginBottom : -5

    },
  
    title: {
      color: '#322153',
      fontSize: 24,
      fontFamily: 'Ubuntu_700Bold',
      maxWidth: 200,
      marginTop: 20,
    },
  
    description: {
      color: '#6C6C80',
      fontSize: 16,
      marginTop: 16,
      fontFamily: 'Roboto_400Regular',
      maxWidth: 260,
      lineHeight: 24,
    },
  
    footer: {},
  
    select: {},
  
    input: {
      height: 50,
      backgroundColor: '#FFF',
      borderRadius: 10,
      marginBottom: 10,
      paddingHorizontal: 24,
      fontSize: 16,
    },

    input2: {
        height: 50,
        width: 150,
        justifyContent: 'center',
        flexDirection: 'row',
        backgroundColor: '#FFF',
        borderRadius: 10,
        marginBottom: 10,
        paddingHorizontal: 24,
        fontSize: 16,
      },
      input3: {
        height: 50,
        width: 150,
        flexDirection : 'row',
        justifyContent: 'space-around',
        backgroundColor: '#FFF',
        borderRadius: 10,
        marginBottom: 10,
        paddingHorizontal: 24,
        fontSize: 16,
      },
  
    button: {
      backgroundColor: '#34CB79',
      height: 60,
      flexDirection: 'row',
      borderRadius: 10,
      overflow: 'hidden',
      alignItems: 'center',
      marginTop: 8,
    },
    button2: {
      backgroundColor: '#008553',
      height: 60,
      flexDirection: 'row',
      borderRadius: 10,
      overflow: 'hidden',
      alignItems: 'center',
      marginTop: 8,
    },


  
    buttonIcon: {
      height: 60,
      width: 60,
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
      justifyContent: 'center',
      alignItems: 'center'
    },
  
    buttonText: {
      flex: 1,
      justifyContent: 'center',
      textAlign: 'center',
      color: '#FFF',
      fontFamily: 'Roboto_500Medium',
      fontSize: 16,
    }
  });

export default CadUser;